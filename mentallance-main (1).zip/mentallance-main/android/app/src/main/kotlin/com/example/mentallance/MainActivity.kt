package com.example.mentallance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
