library TaskAssignment;

import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


import 'package:mentallance/components/assets.dart';
import 'package:mentallance/components/custom_widgets/custom_w%C4%B1dgets.dart';
import 'package:mentallance/components/reusable_widgets/reusable_button.dart';
import 'package:mentallance/components/reusable_widgets/reusable_text_field.dart';
import 'package:mentallance/theme/color_schemes.g.dart';

import 'package:mentallance/view/Doctor_interface/client_list_page/add_customer.dart';
part 'package:mentallance/view/TaskAssignment/deneme.dart';
part 'package:mentallance/view/TaskAssignment/odevListe.dart';
