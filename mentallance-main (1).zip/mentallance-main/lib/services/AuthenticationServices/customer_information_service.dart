part of authentication;

userInformation(_userNameTextController,_userSurnameTextController){

  
}
 
