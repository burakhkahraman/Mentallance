part of customwidgets;

AppBar customAppBarr(BuildContext context, String title) {
  return AppBar(title: Text(title), centerTitle: true,backgroundColor: Colors.transparent,);
}
